package transform;

public interface ILogicalTransformer {

}
