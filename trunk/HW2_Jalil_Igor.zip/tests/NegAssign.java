package tests;
public class NegAssign {

    public static void main(String args[]) {
        int a;
        int k = 5;
        int j = -k;
        int m = -j;
    }
    
}