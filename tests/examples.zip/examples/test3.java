package examples;

public class prog3 {

	public static void foo() {
		int j = 0;
		for (int i = 0; i < 100; i++) {
		  j = j + 2;
		}
	}

}