package tests;
public class Assign {

	public static void main(String args[]) {
		int a;
	    int k = 5; //k = [5,5]
        int j = k; //j=[5,5], k=[5,5]
		int l = args.length; //j=[5,5], k=[5,5], l = [-inf,inf]
	}
	
}